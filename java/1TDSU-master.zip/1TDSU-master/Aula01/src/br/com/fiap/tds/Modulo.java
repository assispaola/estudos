package br.com.fiap.tds;

public class Modulo {

	public static void main(String args[]) {
		//Declarar uma vari�vel para armazenar 
		//a qtd de alunos da sala
		int qtdAlunos = 39;
		
		//Incrementa em 1 o valor da vari�vel
		qtdAlunos++; //qtdAlunos = qtdAlunos + 1;
		
		//Adicionar um valor para a quantidade de alunos
		qtdAlunos += 3; //qtdAlunos = qtdAlunos + 3;
		
		//Os grupos de projetos devem conter 6 alunos
		//Exibir a quantidade de grupos da sala
		int grupos = qtdAlunos / 6;
		System.out.println("Grupos: " + grupos);
		
		//Exibir a quantidade de alunos sem grupo
		//Calcula o resto da divis�o
		int semGrupo = qtdAlunos % 6;
		System.out.println("Alunos sem grupo: " + semGrupo);
		
		
	}
	
}