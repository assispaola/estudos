package br.com.fiap.tds;

import java.util.Scanner;

public class Loja {

	public static void main(String args[]) {
		//Declarar o leitor de teclado
		Scanner leitor = new Scanner(System.in);
		
		//Ler o pre�o do produto
		System.out.println("Digite o pre�o:");
		double preco = leitor.nextDouble();
		
		//Ler o desconto
		System.out.println("Digite o desconto: (%)");
		double desconto = leitor.nextDouble();
		
		//Calcular o pre�o com o desconto
		double valorFinal = preco - preco*desconto/100;
		
		//Exibir o resultado
		System.out.println("Pre�o final: " + valorFinal);
		
		//fechar o leitor
		leitor.close();
	}
	
}