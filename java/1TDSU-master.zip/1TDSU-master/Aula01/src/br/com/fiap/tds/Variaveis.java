package br.com.fiap.tds;

public class Variaveis {

	public static void main(String args[]) {
		//declarar uma vari�vel
		float notaPrimeiroSemestre;
		float notaSegundoSemestre = 5;
		
		boolean aprovado = true;
		
		//o valor do char � com aspas simples
		char turma = 'U';
		//String � com aspas duplas
		String curso = "TDS";
		
		//Atribuir um valor para o primeiroSemestre
		notaPrimeiroSemestre = 7;
		
		//Calcular a m�dia final -  1S-40% + 2S-60%
		double media = notaPrimeiroSemestre * 0.4 
			+ notaSegundoSemestre * 0.6;
		
		//Exibir a m�dia final
		System.out.println("M�dia final: " + media);
		
	}
	
}
