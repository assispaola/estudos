package br.com.fiap.tds;

public class OlaMundo {

	//M�todo que � excecutado quando a aplica��o roda
	public static void main(String args[]) {
		//Exibir um texto
		System.out.println("Ol� Mundo!");
	}
	
	
}