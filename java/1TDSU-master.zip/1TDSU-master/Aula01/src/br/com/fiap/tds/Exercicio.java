package br.com.fiap.tds;

import java.util.Scanner;

public class Exercicio {

	public static void main(String args[]) {
		//Objeto utilizado na leitura do teclado
		Scanner leitor = new Scanner(System.in);
		
		//Ler o nome do aluno
		System.out.println("Digite o nome do aluno:");
		String nome = leitor.next(); //L� uma String 
		
		System.out.println("Digite a m�dia final:");
		//Ler a m�dia final
		float media = leitor.nextFloat();
		
		//Calcular a nota m�nima de exame (12 - m�dia)
		float exame = 12 - media;
		
		//Exibir o nome do aluno e a nota minima
		System.out.println("Aluno: " + nome + 
				" Nota exame: " + exame);
		
		//Fechar o leitor
		leitor.close();
	}
	
}