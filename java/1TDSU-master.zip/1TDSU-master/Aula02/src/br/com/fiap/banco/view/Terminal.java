package br.com.fiap.banco.view;

import java.util.Scanner;

import br.com.fiap.banco.bean.Conta;

public class Terminal {

	public static void main(String args[]) {
		//Objeto para ler o teclado
		Scanner leitor = new Scanner(System.in);
		
		//Criando um objeto do tipo Conta
		Conta poupanca = new Conta();
		//Ler os valores dos atributos da classe Conta
		System.out.println("Digite a agencia:");
		poupanca.agencia = leitor.nextInt(); 
		System.out.println("Digite o nome:");
		poupanca.nome = leitor.next();
		System.out.println("Digite o saldo:");
		poupanca.saldo = leitor.nextDouble();
		System.out.println("Digite se est� ativo:");
		poupanca.ativo = leitor.nextBoolean();
		System.out.println("Digite a senha:");
		poupanca.senha = leitor.next();
		
		//Exibir os valores do objeto
		System.out.println("Agencia " + poupanca.agencia);
		System.out.println("Saldo " + poupanca.saldo);
		System.out.println("Nome " + poupanca.nome);
		System.out.println("Ativo " + poupanca.ativo);
		System.out.println("Senha " + poupanca.senha);
		
		leitor.close(); //fechar o leitor
	}
	
}