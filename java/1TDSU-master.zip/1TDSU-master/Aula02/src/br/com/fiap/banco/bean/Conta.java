package br.com.fiap.banco.bean;

public class Conta {

	//Atributos 
	public int agencia;
	
	public String nome;
	
	public double saldo;
	
	public boolean ativo;
	
	public char tipoConta;
	
	public String senha;
	
}